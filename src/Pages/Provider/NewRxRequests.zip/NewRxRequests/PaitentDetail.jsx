import Footer from "../../../Compunents/Footer"
import Navbare from "../../../Compunents/Navbar"
import PaitentDeatilForm from "./PaitentDeatilForm"


const PaitentDetail = () => {
  return (
    <>
    
    <Navbare/>

    <PaitentDeatilForm/>
    <Footer/>

    
    
    </>
  )
}

export default PaitentDetail