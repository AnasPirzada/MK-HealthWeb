import Footer from "../../../Compunents/Footer"
import Navbare from "../../../Compunents/Navbar"
import PendingRequest from "./PendingRequest"


const RxRequest = () => {
  return (
  <>
  <Navbare/>
  <PendingRequest/>
  <Footer/>
  
  </>
  )
}

export default RxRequest