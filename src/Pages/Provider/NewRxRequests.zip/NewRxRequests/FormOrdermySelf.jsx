import React from 'react'

export const FormOrdermySelf = () => {
  return (
    <div>FormOrdermySelf</div>
  )
}
export default FormOrdermySelf